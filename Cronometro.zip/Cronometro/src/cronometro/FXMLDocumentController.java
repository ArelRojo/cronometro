/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cronometro;

import java.net.URL;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ResourceBundle;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;


/**
 *
 * @author lisas
 */
public class FXMLDocumentController implements Initializable {

    private Label label;
    @FXML
    private Label cr_hora;
    private CronoService crono;
    boolean empezar = true;
    @FXML
    private Button bt_start;
    @FXML
    private Button bt_stop;
    @FXML
    private Button bt_reset;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        crono = new CronoService();
        cr_hora.textProperty().bind(crono.messageProperty());
        bt_start.disableProperty().bind(crono.runningProperty());
        bt_stop.disableProperty().bind(crono.runningProperty().not());
        bt_reset.disableProperty().bind(crono.runningProperty().not());
    }

    @FXML
    private void bt_start(ActionEvent event) {
        if (empezar) {
            crono.start();
            empezar = false;
        } else {
            crono.restart();
        }
    }

    @FXML
    private void bt_stop(ActionEvent event) {
        crono.cancel();
    }

    @FXML
    private void bt_reset(ActionEvent event) {
        crono.reset();
        
    }

}

class CronoService extends Service<Void> {
    private long parado ;
    private long t_init;

    @Override
    protected Task<Void> createTask() {
        return new Task<Void>() {
            
                         
            @Override
            protected void cancelled() {
                super.cancelled();
                parado =  System.currentTimeMillis() - t_init;
                //To change body of generated methods, choose Tools | Templates.
            }
            
            
            @Override
            protected Void call() throws Exception {
                 t_init = System.currentTimeMillis();
                 t_init = t_init - parado;
                 
                while (true) {
                     long t_last = System.currentTimeMillis();
                    Duration t_transcurrido = Duration.ofMillis(t_last - t_init) ;
                    String minutos = null;
                    if(t_transcurrido.toMinutes() < 10 ){
                        minutos = "0" + String.format("%d", t_transcurrido.toMinutes());
                    }else { minutos = String.format("%d", t_transcurrido.toMinutes());}
                    String nano = null;
                    if(t_transcurrido.minusMinutes(t_transcurrido.toMinutes()).getSeconds() < 10){
                      nano = "0" + String.format("%d", t_transcurrido.minusMinutes(t_transcurrido.toMinutes()).getSeconds());
                    }else{nano = String.format("%d", t_transcurrido.minusMinutes(t_transcurrido.toMinutes()).getSeconds());}
                    String horas = null;
                    if(t_transcurrido.toHours() < 1){
                        horas = "00";
                    }else if(t_transcurrido.toHours() < 10){
                        horas = "0" + String.format("%d", t_transcurrido.toHours());
                    }else{
                        horas = String.format("%d", t_transcurrido.toHours());
                    }
                
            
                    
                updateMessage(String.format(horas + ":" + minutos + ":" + nano));
//                 

                    Thread.sleep(100);

                }
            }
           
       };
    }

  

}


